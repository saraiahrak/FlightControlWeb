export class Segment {
    longitude: number;
    latitude: number;
    timespan_seconds: number;
}
