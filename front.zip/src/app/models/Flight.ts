export class Flight {
    flight_id: string;
    longitude: number;
    latitude: number;
    passengers: number;
    company_name: string;
    date_time: string;
    is_external: boolean;
}
