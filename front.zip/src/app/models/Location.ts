export class Location {
    longitude: number;
    latitude: number;
    date_time: string;
}
