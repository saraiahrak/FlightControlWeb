export interface Alert {
    title: string;
    description: string;
    icon?: string;
}
