export class ServerInfo {
    ServerId: string;
    ServerURL: string;
}
